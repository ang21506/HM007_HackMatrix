import { UserProfile, CreditScoreData } from '@/app/types';

export function calculateCreditScore(profile: UserProfile): number {
  if (!profile.monthlyIncome) return 0;
  
  let score = 300; // Base score

  // Income factor (0-200 points)
  const incomeScore = Math.min(200, (profile.monthlyIncome / 1000) * 2);
  score += incomeScore;

  // Debt-to-Income ratio (0-250 points)
  const totalDebt = profile.existingEMI;
  const dti = totalDebt / profile.monthlyIncome;
  const dtiScore = Math.max(0, 250 - (dti * 500));
  score += dtiScore;

  // Expense ratio (0-150 points)
  const expenseRatio = profile.monthlyExpenses / profile.monthlyIncome;
  const expenseScore = Math.max(0, 150 - (expenseRatio * 300));
  score += expenseScore;

  // Existing loans penalty (0-100 points)
  const loanPenalty = Math.min(100, profile.existingLoans * 20);
  score -= loanPenalty;

  // Employment type bonus
  if (profile.employmentType === 'salaried') {
    score += 50;
  } else if (profile.employmentType === 'self-employed') {
    score += 30;
  }

  // Age factor
  if (profile.age >= 25 && profile.age <= 55) {
    score += 50;
  } else if (profile.age >= 18 && profile.age < 25) {
    score += 20;
  }

  return Math.min(900, Math.max(300, Math.round(score)));
}

export function generateMockCreditHistory(currentScore: number): CreditScoreData[] {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const history: CreditScoreData[] = [];
  
  let score = currentScore - 100;
  
  for (const month of months) {
    score += Math.random() * 30 - 10;
    score = Math.min(900, Math.max(300, score));
    history.push({
      month,
      score: Math.round(score)
    });
  }
  
  // Make sure last month is the current score
  history[history.length - 1].score = currentScore;
  
  return history;
}

export function calculateEMI(principal: number, rate: number, tenure: number): number {
  const monthlyRate = rate / 12 / 100;
  const emi = principal * monthlyRate * Math.pow(1 + monthlyRate, tenure) / (Math.pow(1 + monthlyRate, tenure) - 1);
  return Math.round(emi);
}

export function calculateLoanEligibility(profile: UserProfile): {
  eligible: boolean;
  maxLoanAmount: number;
  reason: string;
} {
  const disposableIncome = profile.monthlyIncome - profile.monthlyExpenses - profile.existingEMI;
  const maxEMI = disposableIncome * 0.5; // 50% of disposable income
  
  if (disposableIncome <= 0) {
    return {
      eligible: false,
      maxLoanAmount: 0,
      reason: 'Insufficient disposable income'
    };
  }
  
  if (profile.monthlyIncome < 25000) {
    return {
      eligible: false,
      maxLoanAmount: 0,
      reason: 'Minimum income requirement not met'
    };
  }
  
  // Assuming 10% interest rate and 5 years (60 months) tenure for max loan calculation
  const maxLoanAmount = (maxEMI * 60) / (0.00833 * Math.pow(1.00833, 60) / (Math.pow(1.00833, 60) - 1));
  
  return {
    eligible: true,
    maxLoanAmount: Math.round(maxLoanAmount),
    reason: 'Eligible for loan'
  };
}
