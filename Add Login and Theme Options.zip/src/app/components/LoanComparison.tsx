import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { calculateEMI } from '@/app/utils/loanCalculations';
import { GitCompare, CheckCircle } from 'lucide-react';

interface LoanOption {
  id: string;
  bank: string;
  interestRate: number;
  processingFee: number;
  tenure: number;
}

export function LoanComparison() {
  const [loanAmount, setLoanAmount] = useState(500000);
  const [loanOptions] = useState<LoanOption[]>([
    {
      id: '1',
      bank: 'HDFC Bank',
      interestRate: 10.5,
      processingFee: 2,
      tenure: 60,
    },
    {
      id: '2',
      bank: 'SBI',
      interestRate: 9.8,
      processingFee: 1.5,
      tenure: 60,
    },
    {
      id: '3',
      bank: 'ICICI Bank',
      interestRate: 10.25,
      processingFee: 2.5,
      tenure: 60,
    },
    {
      id: '4',
      bank: 'Axis Bank',
      interestRate: 10.75,
      processingFee: 2,
      tenure: 60,
    },
  ]);

  const calculateLoanDetails = (option: LoanOption) => {
    const emi = calculateEMI(loanAmount, option.interestRate, option.tenure);
    const totalAmount = emi * option.tenure;
    const totalInterest = totalAmount - loanAmount;
    const processingFeeAmount = (loanAmount * option.processingFee) / 100;
    const totalCost = totalAmount + processingFeeAmount;

    return {
      emi,
      totalAmount,
      totalInterest,
      processingFeeAmount,
      totalCost,
    };
  };

  const optionsWithDetails = loanOptions.map((option) => ({
    ...option,
    ...calculateLoanDetails(option),
  }));

  // Find best option (lowest total cost)
  const bestOption = optionsWithDetails.reduce((best, current) =>
    current.totalCost < best.totalCost ? current : best
  );

  return (
    <Card className="dark:bg-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 dark:text-white">
          <GitCompare className="size-5" />
          Loan Comparison
        </CardTitle>
        <CardDescription className="dark:text-gray-400">
          Compare loan offers from different banks
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Loan Amount Input */}
          <div className="bg-blue-50 dark:bg-gray-700 p-4 rounded-lg">
            <label className="flex justify-between text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <span>Loan Amount</span>
              <span className="text-blue-600 dark:text-blue-400">₹{loanAmount.toLocaleString()}</span>
            </label>
            <input
              type="range"
              min="100000"
              max="5000000"
              step="50000"
              value={loanAmount}
              onChange={(e) => setLoanAmount(parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 dark:bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span>₹1L</span>
              <span>₹50L</span>
            </div>
          </div>

          {/* Comparison Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="text-left py-3 px-2 font-medium text-gray-900 dark:text-white">Bank</th>
                  <th className="text-right py-3 px-2 font-medium text-gray-900 dark:text-white">Rate</th>
                  <th className="text-right py-3 px-2 font-medium text-gray-900 dark:text-white">EMI</th>
                  <th className="text-right py-3 px-2 font-medium text-gray-900 dark:text-white">Interest</th>
                  <th className="text-right py-3 px-2 font-medium text-gray-900 dark:text-white">Fee</th>
                  <th className="text-right py-3 px-2 font-medium text-gray-900 dark:text-white">Total Cost</th>
                </tr>
              </thead>
              <tbody>
                {optionsWithDetails.map((option) => (
                  <tr
                    key={option.id}
                    className={`border-b border-gray-100 dark:border-gray-700 ${
                      option.id === bestOption.id
                        ? 'bg-green-50 dark:bg-green-900/20'
                        : 'hover:bg-gray-50 dark:hover:bg-gray-700/50'
                    }`}
                  >
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-gray-900 dark:text-white">{option.bank}</span>
                        {option.id === bestOption.id && (
                          <CheckCircle className="size-4 text-green-600 dark:text-green-400" />
                        )}
                      </div>
                    </td>
                    <td className="text-right py-3 px-2 text-gray-700 dark:text-gray-300">
                      {option.interestRate}%
                    </td>
                    <td className="text-right py-3 px-2 font-medium text-gray-900 dark:text-white">
                      ₹{option.emi.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-2 text-gray-700 dark:text-gray-300">
                      ₹{option.totalInterest.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-2 text-gray-700 dark:text-gray-300">
                      ₹{option.processingFeeAmount.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-2 font-medium text-gray-900 dark:text-white">
                      ₹{option.totalCost.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Best Option Highlight */}
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 p-4 rounded-lg">
            <div className="flex items-start gap-3">
              <CheckCircle className="size-6 text-green-600 dark:text-green-400 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-green-900 dark:text-green-400">Best Offer</h4>
                <p className="text-sm text-green-700 dark:text-green-500 mt-1">
                  {bestOption.bank} offers the lowest total cost of ₹{bestOption.totalCost.toLocaleString()} with an EMI of ₹{bestOption.emi.toLocaleString()}/month
                </p>
              </div>
            </div>
          </div>

          {/* Detailed Comparison Cards for Mobile */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:hidden">
            {optionsWithDetails.map((option) => (
              <div
                key={option.id}
                className={`p-4 border rounded-lg ${
                  option.id === bestOption.id
                    ? 'border-green-500 dark:border-green-600 bg-green-50 dark:bg-green-900/20'
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-gray-900 dark:text-white">{option.bank}</h4>
                  {option.id === bestOption.id && (
                    <CheckCircle className="size-5 text-green-600 dark:text-green-400" />
                  )}
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Interest Rate:</span>
                    <span className="font-medium text-gray-900 dark:text-white">{option.interestRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Monthly EMI:</span>
                    <span className="font-medium text-gray-900 dark:text-white">₹{option.emi.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Total Interest:</span>
                    <span className="font-medium text-gray-900 dark:text-white">₹{option.totalInterest.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Processing Fee:</span>
                    <span className="font-medium text-gray-900 dark:text-white">₹{option.processingFeeAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-gray-200 dark:border-gray-600">
                    <span className="text-gray-900 dark:text-white font-medium">Total Cost:</span>
                    <span className="font-bold text-gray-900 dark:text-white">₹{option.totalCost.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Note */}
          <div className="bg-blue-50 dark:bg-gray-700 p-4 rounded-lg">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              <strong>Note:</strong> All calculations assume a 5-year (60 months) tenure. Interest rates and processing fees are indicative and may vary. Please check with the respective banks for current rates and offers.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
