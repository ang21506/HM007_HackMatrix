import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { calculateEMI } from '@/app/utils/loanCalculations';
import { Calculator, PieChart } from 'lucide-react';

export function EMICalculator() {
  const [principal, setPrincipal] = useState(500000);
  const [rate, setRate] = useState(10);
  const [tenure, setTenure] = useState(60);

  const emi = calculateEMI(principal, rate, tenure);
  const totalAmount = emi * tenure;
  const totalInterest = totalAmount - principal;

  return (
    <Card className="dark:bg-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 dark:text-white">
          <Calculator className="size-5" />
          EMI Calculator
        </CardTitle>
        <CardDescription className="dark:text-gray-400">
          Calculate your monthly EMI for loans
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Section */}
          <div className="space-y-6">
            <div>
              <label className="flex justify-between text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <span>Loan Amount</span>
                <span className="text-blue-600 dark:text-blue-400">₹{principal.toLocaleString()}</span>
              </label>
              <input
                type="range"
                min="10000"
                max="10000000"
                step="10000"
                value={principal}
                onChange={(e) => setPrincipal(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 dark:bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                <span>₹10K</span>
                <span>₹1Cr</span>
              </div>
            </div>

            <div>
              <label className="flex justify-between text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <span>Interest Rate (% p.a.)</span>
                <span className="text-blue-600 dark:text-blue-400">{rate}%</span>
              </label>
              <input
                type="range"
                min="1"
                max="30"
                step="0.1"
                value={rate}
                onChange={(e) => setRate(parseFloat(e.target.value))}
                className="w-full h-2 bg-gray-200 dark:bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                <span>1%</span>
                <span>30%</span>
              </div>
            </div>

            <div>
              <label className="flex justify-between text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <span>Loan Tenure (months)</span>
                <span className="text-blue-600 dark:text-blue-400">{tenure} months</span>
              </label>
              <input
                type="range"
                min="6"
                max="360"
                step="6"
                value={tenure}
                onChange={(e) => setTenure(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 dark:bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                <span>6 months</span>
                <span>30 years</span>
              </div>
            </div>

            {/* Quick Input Fields */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-gray-600 dark:text-gray-400">Principal</label>
                <input
                  type="number"
                  value={principal}
                  onChange={(e) => setPrincipal(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label className="text-xs text-gray-600 dark:text-gray-400">Rate %</label>
                <input
                  type="number"
                  value={rate}
                  onChange={(e) => setRate(parseFloat(e.target.value) || 0)}
                  step="0.1"
                  className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                />
              </div>
              <div>
                <label className="text-xs text-gray-600 dark:text-gray-400">Months</label>
                <input
                  type="number"
                  value={tenure}
                  onChange={(e) => setTenure(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white p-6 rounded-xl">
              <p className="text-sm opacity-90 mb-1">Monthly EMI</p>
              <p className="text-4xl font-bold">₹{emi.toLocaleString()}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <p className="text-sm text-green-700 dark:text-green-400">Principal Amount</p>
                <p className="text-xl font-bold text-green-900 dark:text-green-300">₹{principal.toLocaleString()}</p>
              </div>
              <div className="p-4 bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg">
                <p className="text-sm text-orange-700 dark:text-orange-400">Total Interest</p>
                <p className="text-xl font-bold text-orange-900 dark:text-orange-300">₹{totalInterest.toLocaleString()}</p>
              </div>
            </div>

            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Amount Payable</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">₹{totalAmount.toLocaleString()}</p>
            </div>

            {/* Visual Breakdown */}
            <div className="p-4 bg-blue-50 dark:bg-gray-700 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <PieChart className="size-5 text-blue-600 dark:text-blue-400" />
                <h4 className="font-medium text-gray-900 dark:text-white">Payment Breakdown</h4>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-gray-700 dark:text-gray-300">Principal</span>
                  </div>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {((principal / totalAmount) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                    <span className="text-gray-700 dark:text-gray-300">Interest</span>
                  </div>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {((totalInterest / totalAmount) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
              <div className="mt-3 h-3 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden flex">
                <div
                  className="bg-green-500"
                  style={{ width: `${(principal / totalAmount) * 100}%` }}
                ></div>
                <div
                  className="bg-orange-500"
                  style={{ width: `${(totalInterest / totalAmount) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
