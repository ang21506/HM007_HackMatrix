import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { CreditScoreData } from '@/app/types';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface CreditScoreTrackerProps {
  creditScore: number;
  history: CreditScoreData[];
}

export function CreditScoreTracker({ creditScore, history }: CreditScoreTrackerProps) {
  const getScoreColor = (score: number) => {
    if (score >= 750) return 'text-green-600 dark:text-green-400';
    if (score >= 650) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getScoreRating = (score: number) => {
    if (score >= 750) return 'Excellent';
    if (score >= 650) return 'Good';
    if (score >= 550) return 'Fair';
    return 'Poor';
  };

  const getTrend = () => {
    if (history.length < 2) return null;
    const diff = history[history.length - 1].score - history[history.length - 2].score;
    if (diff > 0) return { icon: TrendingUp, text: `+${diff} from last month`, color: 'text-green-600' };
    if (diff < 0) return { icon: TrendingDown, text: `${diff} from last month`, color: 'text-red-600' };
    return { icon: Minus, text: 'No change', color: 'text-gray-600' };
  };

  const trend = getTrend();

  return (
    <Card className="dark:bg-gray-800">
      <CardHeader>
        <CardTitle className="dark:text-white">Credit Score Tracker</CardTitle>
        <CardDescription className="dark:text-gray-400">
          Monitor your credit score over time
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Current Score Display */}
          <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-700 dark:to-gray-600 rounded-xl">
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">Your Credit Score</p>
            <p className={`text-5xl font-bold ${getScoreColor(creditScore)}`}>
              {creditScore}
            </p>
            <p className="text-lg text-gray-700 dark:text-gray-300 mt-2">
              {getScoreRating(creditScore)}
            </p>
            {trend && (
              <div className={`flex items-center justify-center gap-1 mt-3 ${trend.color}`}>
                <trend.icon className="size-4" />
                <span className="text-sm">{trend.text}</span>
              </div>
            )}
          </div>

          {/* Score Range Indicator */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400">
              <span>Poor</span>
              <span>Fair</span>
              <span>Good</span>
              <span>Excellent</span>
            </div>
            <div className="h-3 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 rounded-full relative">
              <div
                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white dark:bg-gray-800 border-2 border-blue-600 rounded-full"
                style={{ left: `${((creditScore - 300) / 600) * 100}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400">
              <span>300</span>
              <span>900</span>
            </div>
          </div>

          {/* Credit Score History Chart */}
          {history.length > 0 && (
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">6-Month Trend</h4>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" className="dark:opacity-30" />
                  <XAxis 
                    dataKey="month" 
                    tick={{ fill: 'currentColor' }} 
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <YAxis 
                    domain={[300, 900]} 
                    tick={{ fill: 'currentColor' }} 
                    className="text-gray-600 dark:text-gray-400"
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'var(--tooltip-bg, white)', 
                      border: '1px solid #ccc',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#2563eb" 
                    strokeWidth={2}
                    dot={{ fill: '#2563eb', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Score Improvement Tips */}
          <div className="bg-blue-50 dark:bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Tips to Improve Your Score</h4>
            <ul className="space-y-1 text-sm text-gray-700 dark:text-gray-300">
              <li>• Pay all EMIs on time</li>
              <li>• Reduce your debt-to-income ratio</li>
              <li>• Minimize credit inquiries</li>
              <li>• Maintain low credit utilization</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
