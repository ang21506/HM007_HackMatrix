import { UserProfile } from '@/app/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { calculateLoanEligibility } from '@/app/utils/loanCalculations';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';

interface LoanEligibilityCheckerProps {
  profile: UserProfile | null;
}

export function LoanEligibilityChecker({ profile }: LoanEligibilityCheckerProps) {
  if (!profile) {
    return (
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="dark:text-white">Loan Eligibility Checker</CardTitle>
          <CardDescription className="dark:text-gray-400">
            Check your eligibility for various types of loans
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <AlertCircle className="size-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">
              Please complete your financial profile to check loan eligibility
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const eligibility = calculateLoanEligibility(profile);
  const disposableIncome = profile.monthlyIncome - profile.monthlyExpenses - profile.existingEMI;

  const loanTypes = [
    {
      name: 'Personal Loan',
      interestRate: '10-15%',
      maxAmount: eligibility.maxLoanAmount,
      eligible: eligibility.eligible,
      tenure: '1-5 years',
    },
    {
      name: 'Home Loan',
      interestRate: '8-10%',
      maxAmount: eligibility.maxLoanAmount * 3,
      eligible: eligibility.eligible && profile.monthlyIncome >= 30000,
      tenure: '10-30 years',
    },
    {
      name: 'Car Loan',
      interestRate: '9-12%',
      maxAmount: eligibility.maxLoanAmount * 1.5,
      eligible: eligibility.eligible && profile.monthlyIncome >= 25000,
      tenure: '3-7 years',
    },
    {
      name: 'Education Loan',
      interestRate: '8-12%',
      maxAmount: eligibility.maxLoanAmount * 2,
      eligible: eligibility.eligible,
      tenure: '5-15 years',
    },
  ];

  return (
    <Card className="dark:bg-gray-800">
      <CardHeader>
        <CardTitle className="dark:text-white">Loan Eligibility Checker</CardTitle>
        <CardDescription className="dark:text-gray-400">
          Check your eligibility for various types of loans
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Overall Eligibility Status */}
          <div className={`p-4 rounded-lg ${eligibility.eligible ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800' : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'}`}>
            <div className="flex items-start gap-3">
              {eligibility.eligible ? (
                <CheckCircle className="size-6 text-green-600 dark:text-green-400 flex-shrink-0" />
              ) : (
                <XCircle className="size-6 text-red-600 dark:text-red-400 flex-shrink-0" />
              )}
              <div>
                <h3 className={`font-semibold ${eligibility.eligible ? 'text-green-900 dark:text-green-400' : 'text-red-900 dark:text-red-400'}`}>
                  {eligibility.eligible ? 'Eligible for Loans' : 'Not Eligible'}
                </h3>
                <p className={`text-sm mt-1 ${eligibility.eligible ? 'text-green-700 dark:text-green-500' : 'text-red-700 dark:text-red-500'}`}>
                  {eligibility.reason}
                </p>
              </div>
            </div>
          </div>

          {/* Financial Summary */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="text-sm text-gray-600 dark:text-gray-400">Monthly Income</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">₹{profile.monthlyIncome.toLocaleString()}</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="text-sm text-gray-600 dark:text-gray-400">Disposable Income</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">₹{disposableIncome.toLocaleString()}</p>
            </div>
          </div>

          {/* Loan Types Grid */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 dark:text-white">Loan Types</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {loanTypes.map((loan) => (
                <div
                  key={loan.name}
                  className={`p-4 border rounded-lg ${loan.eligible ? 'border-green-200 dark:border-green-800 bg-green-50/50 dark:bg-green-900/10' : 'border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50'}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <h4 className="font-medium text-gray-900 dark:text-white">{loan.name}</h4>
                    {loan.eligible ? (
                      <CheckCircle className="size-5 text-green-600 dark:text-green-400" />
                    ) : (
                      <XCircle className="size-5 text-gray-400" />
                    )}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Max Amount:</span>
                      <span className="font-medium text-gray-900 dark:text-white">₹{loan.maxAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Interest Rate:</span>
                      <span className="font-medium text-gray-900 dark:text-white">{loan.interestRate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Tenure:</span>
                      <span className="font-medium text-gray-900 dark:text-white">{loan.tenure}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Factors Affecting Eligibility */}
          <div className="bg-blue-50 dark:bg-gray-700 p-4 rounded-lg">
            <h4 className="font-medium text-gray-900 dark:text-white mb-2">Factors Affecting Eligibility</h4>
            <ul className="space-y-1 text-sm text-gray-700 dark:text-gray-300">
              <li>• Credit Score: Higher scores improve eligibility</li>
              <li>• Income: Minimum ₹25,000/month required</li>
              <li>• Debt-to-Income Ratio: Lower is better</li>
              <li>• Employment Type: Salaried preferred</li>
              <li>• Existing Loans: Fewer loans increase eligibility</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
