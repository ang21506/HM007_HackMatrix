export interface UserProfile {
  name: string;
  age: number;
  employmentType: 'salaried' | 'self-employed' | 'business';
  monthlyIncome: number;
  monthlyExpenses: number;
  existingLoans: number;
  existingEMI: number;
}

export interface CreditScoreData {
  month: string;
  score: number;
}
